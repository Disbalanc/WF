﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.MaximizeBox = false;
            
        }

        private void bnt_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
        }

        private void btn_Random_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            textBox1.Text = $"{rnd.Next(0, 2023)}";
            btn_calculate.PerformClick();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void btn_calculate_Click(object sender, EventArgs e)
        {
            int element = Convert.ToInt32(textBox1.Text) % 12;
            string Result = "";
            switch (element)
            {
                case 0:
                    Result = "Обезьяна";
                    break;
                case 1:
                    Result = "Курица";
                    break;
                case 2:
                    Result = "Собака";
                    break;
                case 3:
                    Result = "Свинья";
                    break;
                case 4:
                    Result = "Крыса";
                    break;
                case 5:
                    Result = "Корова";
                    break;
                case 6:
                    Result = "Тигр";
                    break;
                case 7:
                    Result = "Заяц";
                    break;
                case 8:
                    Result = "Дракон";
                    break;
                case 9:
                    Result = "Змея";
                    break;
                case 10:
                    Result = "Лошадь";
                    break;
                case 11:
                    Result = "Овца";
                    break;
            }
            textBox2.Text = Result;
        }
    }
}
